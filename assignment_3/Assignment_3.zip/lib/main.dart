import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(const MyApp());

}

class MyApp extends StatelessWidget{
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.lightBlue),
      darkTheme: ThemeData(primarySwatch: Colors.lightBlue),
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }

}
class HomePage extends StatelessWidget{
  const HomePage({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child:Material(
          color: Colors.white,
          elevation: 8,
          child: InkWell(
              splashColor: Colors.black26,
              onTap: (){},
              child:Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Ink.image(
                        height: 200,
                        width: 200,
                        image:  AssetImage("assets/Doctor_pic.jpg")

                    ),
                    SizedBox(height: 6,),
                    Text("Doctors App", style: TextStyle(fontSize: 20, color: Colors.black),
                    ),
                    SizedBox(height: 6,),
                    ElevatedButton(onPressed: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context)=> SecondNaxtPage()));
                    }, child: Text("Start")
                    )

                  ]
              )

          ),
        ),
      ),
    );

  }
}

class SecondNaxtPage extends StatelessWidget{
    SecondNaxtPage({super.key});

  var MyItems=[
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"MEDICINE" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"SURGERY" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"GYNAE AND OBS Obs" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"PAEDiATRICS" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"CARDIOLOGY" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"GASTRIOLOGY" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"ORTHOPEDICS" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"SKIN AND VD" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"NEUROLOGY" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"ENT AND EYE" },
    {"img":"https://toppng.com//public/uploads/preview/logo-doctors-logo-black-and-white-vector-11563999612kv1q84czrt.png","title":"BLOOD" },

  ];

    var DetailsPage=[
      {"pageName":MedicineDetails()},
      {"pageName":SurgeryDetails()},
      {"pageName":GynaeDetails()},
      {"pageName":PadiatricsDetails()},
      {"pageName":CardiologyDetails()},
      {"pageName":GastrologyDetails()},
      {"pageName":orthopedicsDetails()},
      {"pageName":SkinDetails()},
      {"pageName":NeurologyDetails()},
      {"pageName":EntDetails()},
      {"pageName":BloodDetails()},
    ];



  MySnackBar(message,context){
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message))
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Doctors App"),
        centerTitle: true,
        elevation: 8,
        actions: [
          IconButton(onPressed: (){
            MySnackBar("i am search button", context);

          }, icon: Icon(Icons.search,size:40,))
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 0,
        onTap: (int index){
          if(index==0){
            MySnackBar("I am home", context);
          }
          if(index==1){
            MySnackBar(" i am setting", context);
          }
          if(index==2){
            MySnackBar("I am comment", context);
          }

        },

        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined),label:"Home"),
          BottomNavigationBarItem(icon: Icon(Icons.settings),label:"setting"),
          BottomNavigationBarItem(icon: Icon(Icons.comment),label:"comment"),

        ],

      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          MySnackBar("I Am Messege Button", context);
        },
        child: Icon(Icons.mail),
      ),


        body: ListView.builder(
            itemCount: MyItems.length,
            itemBuilder:(context,index){
              return Card(
                elevation: 10,
                 margin: EdgeInsets.symmetric(vertical: 20),
                 color: Colors.white54,
                 child: ListTile(
              title: Text("${MyItems[index]['title']}",style: TextStyle(fontWeight: FontWeight.bold)),
              leading: CircleAvatar(
              backgroundImage: NetworkImage('${MyItems[index]['img']}'),
              ),
              onTap:(){
                Navigator.push(context, MaterialPageRoute(builder: (context)=>DetailsPage[index]["pageName"]!));
              } ,
              ),
              );
            }
            ),


    );


  }

}

class MedicineDetails extends StatelessWidget {
   MedicineDetails({Key? key}) : super(key: key);

  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Common Cause Of Breathlesness"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute Severe bronchial Asthma"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"COPD"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Pneumonia"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Lungs Abscess"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Pleural Effusion"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Bronchiectasis"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Pneumothorax"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"RTI"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Pulmonary TB"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Snake Bite"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Poisoning"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute Gastrities"}
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("MEDICINE  "),
      ),
          body: ListView.separated(
                separatorBuilder: (context,index){
                  return Divider(
                    thickness:5,
                  );
                },
              itemCount: MyItems.length,
              itemBuilder:(context,index){
                return Container(

                  margin: EdgeInsets.symmetric(vertical: 7),
                  color:Colors.white54 ,
                  child: ListTile(
                    title: Text("${MyItems[index]['title']}"),
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                    ),
                    onTap:(){

                    } ,
                  ),
                );
              }
          ),

    );
  }
}
class SurgeryDetails extends StatelessWidget {
   SurgeryDetails({Key? key}) : super(key: key);


  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute Gastritis(Food poisoning)"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute PUD"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Haematemesis/Malaena"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Haemoptysis"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Non-ulcer Dyspepsia"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"GERD"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Ulcerative Colities(Bloody Diarrhoea)"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Abdominal Pain"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Head Injury"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Physical assult"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Small Cut Injury"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Abscess"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Hernia & Hydrocele"}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SURGERY"),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),

    );
  }
}
class GynaeDetails extends StatelessWidget {
   GynaeDetails({Key? key}) : super(key: key);


  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Family planning."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Female genitourinary infections."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Gynecologic oncology."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Minimally invasive gynecologic surgery."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Obstetrics and maternal fetal."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Pediatric and adolescent gynecology."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"IUD"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Hyperemesis Gravidarm "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Follow Up Of an ANC Patient"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"vaginal Infection"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Scondary Wond Infection "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Abortion. Breastfeeding. HIV. "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Full Term pregnency With Lap "}
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("GYNAE & OBS "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),



    );
  }
}
class PadiatricsDetails extends StatelessWidget {
   PadiatricsDetails({Key? key}) : super(key: key);

  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Family planning."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Female genitourinary infections."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Gynecologic oncology."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Minimally invasive gynecologic surgery."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Obstetrics and maternal fetal."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Pediatric and adolescent gynecology."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"IUD"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Hyperemesis Gravidarm "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Follow Up Of an ANC Patient"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"vaginal Infection"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Scondary Wond Infection "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Abortion. Breastfeeding. HIV. "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Full Term pregnency With Lap "}
  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("PADIATRICS  "),
      ),


      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),

    );
  }
}
class CardiologyDetails extends StatelessWidget {
   CardiologyDetails({Key? key}) : super(key: key);

  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"AF(Artrial Fibrillation)."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"AMI  ."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"IHD"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"   ISchemic CardioPathy."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" SVT (Supra ventricular tachyvardia) ."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" VF(Ventricular fibrillaton) ."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Vt(ventricular Tachycardia)"},
  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("CARDIOLOGY  "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),


    );
  }
}
class GastrologyDetails extends StatelessWidget {
   GastrologyDetails({Key? key}) : super(key: key);


  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute Gastritia."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute PUD."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"  GERD."}, {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Follow Up Of an ANC Patient"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Oral Thrush"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Liver Abscess "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute Pencreatitis "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Fatty change of liver "}
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("GASTROLOGY  "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),



    );
  }
}
class orthopedicsDetails extends StatelessWidget {
   orthopedicsDetails({Key? key}) : super(key: key);


  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Arthritis."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"  Lower Back Pain.."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Hip Fracture"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Osteoarthritis"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Fibromyalgia   ."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Shoulder Pain ."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Kyphosis"},
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ORTHOPEDICS  "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),



    );
  }
}
class SkinDetails extends StatelessWidget {
   SkinDetails({Key? key}) : super(key: key);

  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acne"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Alopecia "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Eczema "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Scabies "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Tinea Corporis."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Dermatitis "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Erectile dysfuntion"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" measles "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Ichthyosis"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Pemphigus. "},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SKIN & VD   "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),



    );
  }
}
class NeurologyDetails extends StatelessWidget {
   NeurologyDetails({Key? key}) : super(key: key);



  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"AGN"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"NS"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Acute Spinal Cord Injury."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Hyperkalamia"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Brain Tumors.."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Bell's Palsy."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Epilepsy."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Neuromuscular Diseases."},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("NEUROLOGY  "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),


    );
  }
}
class EntDetails extends StatelessWidget {
  EntDetails({Key? key}) : super(key: key);



  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"congenital malformations.."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"autoimmune inner ear disease."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"cholesteatomas.."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"conductive hearing loss."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"diseases of the parathyroid glands."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"diseases of the thyroid glands."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Meniere’s disease"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Refractive Errors. "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Glaucoma."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Strabismus."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Amblyopia. "},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ENT & EYE   "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),


    );
  }
}
class BloodDetails extends StatelessWidget {
  BloodDetails({Key? key}) : super(key: key);


  var MyItems=[
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Aleukaemic laekaemia."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Anemia in Chronic Kidney Disease."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Hemochromatosis."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Hemophilia."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Iron-Deficiency Anemia."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Thalassemias ."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Porphyria"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Vitamin K Deficiency Bleeding. "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" Sickle Cell Disease."},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Lymphoma"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":" CML"},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Blood gruping "},
    {'img':'https://cdn-icons-png.flaticon.com/512/2069/2069604.png',"title":"Women's Blood Disorders. "}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BLOOD "),
      ),

      body: ListView.separated(
          separatorBuilder: (context,index){
            return Divider(
              thickness:5,
            );
          },
          itemCount: MyItems.length,
          itemBuilder:(context,index){
            return Container(

              margin: EdgeInsets.symmetric(vertical: 7),
              color:Colors.white54 ,
              child: ListTile(
                title: Text("${MyItems[index]['title']}"),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage('${MyItems[index]['img']}'),
                ),
                onTap:(){

                } ,
              ),
            );
          }
      ),



    );
  }
}




