
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';

void main (){
  runApp( const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.brown),
      home: ToDoHomePage(),);
  }
}

class ToDoHomePage extends StatelessWidget{
  const ToDoHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child:Material(
          color: Colors.white,
          elevation: 8,
          child: InkWell(
              splashColor: Colors.black26,
              onTap: (){},
              child:Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(height: 20,),
                    Text("ToDo App", style: TextStyle(fontSize: 20, color: Colors.black),
                    ),
                    SizedBox(height: 20,),
                    ElevatedButton(onPressed: (){
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context)=>ToDoListScreen  ()));
                    }, child: Text("Start")
                    )
                  ]
              )

          ),
        ),
      ),
    );
  }

}


class ToDoListScreen extends StatefulWidget {
  const ToDoListScreen({super.key});


  @override
  State<ToDoListScreen> createState() => _ToDoListScreenState();
}

class _ToDoListScreenState extends State<ToDoListScreen> {

  List<String> Items = [];
  TextEditingController ItemNameEditingController = TextEditingController();
  TextEditingController updateItemNameEditingController =
  TextEditingController();



  MySnackBar(message,context){
    return ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message))
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.brown,
        elevation: 10,
        centerTitle: true,
        title: const Text('ToDoList'),
        actions: [
          IconButton(onPressed: (){
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context)=>ToDoHomePage()));}, icon: Icon(Icons.home_outlined)),

        ],
      ),

      drawer: Drawer(
         backgroundColor:Colors.white,
        child: ListView(
          children: [
            DrawerHeader(
              padding: EdgeInsets.all(0),
              child: UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: Colors.brown),
                accountName: Text("Shathi Islam"),
                accountEmail: Text("ishathi092gmail.com"),
                currentAccountPicture: Image.network("https://img.lovepik.com/element/45009/5885.png_300.png"),
              ),
            ),
            ListTile(
                leading: Icon(Icons.home),
                title: Text("Home"),
                onTap: (){
                  MySnackBar("Home menu", context);
                }
            ),
            ListTile(
                leading: Icon(Icons.person),
                title: Text("profile"),
                onTap: (){
                  MySnackBar("profile menu", context);
                }
            ),
            ListTile(
                leading: Icon(Icons.email),
                title: Text("Email"),
                onTap: (){
                  MySnackBar( "Email menu", context);
                }
            ),
            ListTile(
                leading: Icon(Icons.phone),
                title: Text("Contact"),
                onTap: (){
                  MySnackBar("Contact menu", context);
                }
            ),

          ],
        ),
      ),


      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        child: Text('Add',style: TextStyle(fontSize: 16),),
        onPressed: () {
          showModalBottomSheet(
            backgroundColor: Colors.brown[300],
            //backgroundColor: Colors.brown[300],
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
              ),
            ),
            context: context,
            builder: (context) {
              return Padding(
                padding: EdgeInsets.all(18.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ToDo Name',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextField(
                      controller: ItemNameEditingController,
                      decoration: InputDecoration(
                        hintText: 'Write your Todo',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        if (ItemNameEditingController.text.trim().isNotEmpty) {
                          Items.add(ItemNameEditingController.text.trim());
                          ItemNameEditingController.text = '';
                          setState(() {});
                          Navigator.pop(context);
                        }
                      },
                      child: Text(
                        'Add ToDo',
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),



      body: ListView.builder(
        itemCount:Items.length,
        itemBuilder: (context, index) {
           final String todo = Items[(Items.length -1) - index];
             return Padding(
            padding:  EdgeInsets.only(left: 25.0, right: 25.0, top: 10.0),
            child:Card (
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(10),
                ),
              ),
              color: Colors.brown[200],
              elevation:20,
              shadowColor: Colors.white54,
              child: Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
                child: Row(
                  children: [
                    Text(
                      todo,
                      style: TextStyle(
                        fontWeight: FontWeight.w400,
                        fontSize: 20,
                      ),
                    ),
                    Spacer(),

                    IconButton(
                      onPressed: () {
                       Items.removeAt((Items.length-1) - index);
                        setState(() {});
                      },
                      icon: const Icon(
                        Icons.delete,
                        color: Colors.red,
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        updateItemNameEditingController.text = todo;
                        showModalBottomSheet(
                          backgroundColor: Theme.of(context).primaryColor,
                          elevation: 5,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                            ),
                          ),
                          context: context,
                          builder: (context) {
                            return Padding(
                              padding: EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'ToDo name',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 16,
                                  ),
                                  TextField(
                                    controller: updateItemNameEditingController,
                                    decoration: InputDecoration(
                                      hintText: 'Update your Todo',
                                      border: OutlineInputBorder(),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 16,
                                  ),
                                  ElevatedButton(
                                    onPressed: () {
                                      if (updateItemNameEditingController.text
                                          .trim()
                                          .isNotEmpty) {
                                        Items[(Items.length - 1) - index] =
                                            updateItemNameEditingController.text
                                                .trim();

                                        setState(() {});
                                        Navigator.pop(context);
                                      }
                                    },
                                    child: Text('Update ToDo'),
                                  ),
                                ],
                              ),
                            );
                          },
                        );
                      },
                      icon: const Icon(
                        Icons.edit,
                        color: Colors.teal,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
      backgroundColor: Colors.white,


      bottomNavigationBar:BottomAppBar(
        elevation: 5,
        color: Colors.brown,
        shape: CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Expanded (child:IconButton(onPressed: (){MySnackBar("searchButton", context);}, icon:  Icon(Icons.search),splashColor: Colors.pinkAccent,),),
            Expanded(child:IconButton(onPressed: (){MySnackBar("SettingButton", context);}, icon:Icon(Icons.settings),splashColor: Colors.pinkAccent,),)
          ],
        ),
      ),
    );
  }
}
